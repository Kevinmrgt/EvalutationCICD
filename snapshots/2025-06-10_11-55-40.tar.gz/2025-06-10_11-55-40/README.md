# Snapshot 2025-06-10_11-55-40

## 📊 Informations

- **Date** : mar. 10 juin 2025 11:55:40 CEST
- **Commit Git** : f9c7b1c620f7b7d1d524c3adde90468545f74e0e
- **Branche** : main
- **Tag** : v1.1.0

## 📁 Contenu

- `app/` : Code de l'application
- `config/` : Fichiers de configuration
- `infra/` : Infrastructure (Terraform/Ansible)
- `cicd/` : Workflows CI/CD
- `metadata.json` : Métadonnées du snapshot

## 🔄 Restauration

Pour restaurer ce snapshot, utilisez :
```bash
../rollback/restore-snapshot.sh 2025-06-10_11-55-40
```
